package com.example.exam1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
